# mvideo
Тестовое задание для M.SMART ХАКАТОН (http://hackathon.mvideo.ru/)

Для запуска ноутбука необходимо установить следующие библиотеки:
* unrar >= 5.30
* numpy >= 1.12.0
* pandas >= 0.20.1
* scikit-learn >= 0.18.1
* ntlk >= 3.2.4
